﻿window["c2cocoonjs"] = true;
